//
//  MIMEType.swift
//  VAPTData
//
//  Created by Milen Halachev on 24.07.18.
//  Copyright © 2018 Elders Ltd. All rights reserved.
//

import Foundation

//public enum MIMEType: RawRepresentable {
//
//    case image(ImageSubtype)
//    case video(VideoSubtype)
//
//    public var rawValue: String {
//
//        switch self {
//
//            case .image(let subtype):
//                return "image/\(subtype.rawValue)"
//
//            case .video(let subtype):
//                return "video/\(subtype.rawValue)"
//        }
//    }
//
//    public init?(rawValue: String) {
//
//        let components = rawValue.split(separator: "/")
//        guard components.count == 2, let type = components.first, let subtype = components.last else {
//
//            return nil
//        }
//
//        switch (type, subtype) {
//
//            case ("image", let subtype) where ImageSubtype(rawValue: String(subtype)) != nil:
//                let subtype = ImageSubtype(rawValue: String(subtype))!
//                self = .image(subtype)
//
//            case ("video", let subtype) where VideoSubtype(rawValue: String(subtype)) != nil:
//                let subtype = VideoSubtype(rawValue: String(subtype))!
//                self = .video(subtype)
//
//            default:
//                return nil
//        }
//    }
//}
//
//extension MIMEType {
//
//    public enum ImageSubtype: String {
//
//        case jpeg
//        case png
//    }
//
//    public enum VideoSubtype: String {
//
//        case mp4
//    }
//}
